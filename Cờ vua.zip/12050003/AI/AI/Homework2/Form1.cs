﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace AI
{
    public partial class Form1 : Form
    {
        const int R = 10;
        Color line_color = Color.Blue;
        cycle Selectcycle = new cycle();
        cycle cycleA = new cycle();// được dùng để ghi nhớ đường thẳng đầu tiên click để lưu lại vào REf (important)
        
        line Selectedline = new line();
        cycle Selectedcycle = new cycle();

        line buffline = new line();
        List<cycle> lstcycle = new List<cycle>();

        bool isDragging = false;
        bool Mouseisdown= false;
        

        cycle clickedcycle(Point p)
        {
            foreach (cycle item in lstcycle)
            {
                if (item.vitri(p)==2)
                {
                    return item;
                }
            }
            return null;
        }

        line clickline(Point p)
        {
            line a = new line();
            foreach (cycle item in lstcycle)
            {
                a.A = item.I;
                foreach (cycle jtem in item.Ref)
                {
                    //if (((p.X < item.I.X && item.I.X < jtem.I.X )||( p.X > item.I.X && item.I.X > jtem.I.X)) || ((p.Y < item.I.Y && item.I.Y < jtem.I.Y )||( p.Y > item.I.Y && item.I.Y > jtem.I.Y)))
                    //{
                    //    // nếu không nằm trong khoảng hoành độ hoặc tung độ của đoạn thẳng, loại trường hợp đó
                    //    break;
                    //}
                    //else
                    {
                        a.B = jtem.I;
                        if(a.Khoangcachden(p)<=3)
                        {
                            return a;
                        }
                    }
                }
            }
            return null;
        }

        public Form1()
        {
            InitializeComponent();
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            Cursor.Clip = new Rectangle(this.Location, this.Size);
            buffline.cl = Color.Blue;
            this.Focus();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            // nếu đang xác định các node
            if (rdbDrawcycle.Checked == true)
            {

                if (clickedcycle(e.Location) == null)
                {
                    cycle hinhtron = new cycle(e.Location, R, Color.Blue);
                    lstcycle.Add(hinhtron);
                    Refresh();
                }
                else
                {
                    isDragging = true;
                    Selectcycle = clickedcycle(e.Location);
                }
            }
            else if(rdbDrawline.Checked == true)
            {
                // đang vẽ các đường
                Selectcycle = clickedcycle(e.Location);
                // ấn vào 1 hình tròn
                if (Selectcycle!=null)
                {
                    // ghi nhận đường thẳng đầu
                    cycleA = Selectcycle;
                    // lấy điểm đầu là tâm đường tròn được chọn
                        buffline.A = Selectcycle.I;
                        isDragging = true;
                }
            }
            Mouseisdown = true;
        }

       
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foreach (cycle item in lstcycle)
            {
                item.show(e.Graphics);
            }
            if (Selectedline!=null&&rdbremoveline.Checked==true)
            {
                Selectedline.Show(e.Graphics);
            }
            buffline.Show(e.Graphics);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            // nếu chuột đang ấn
            if (Mouseisdown == true)
            {
                // nếu đang vẽ các hình tròn
                if (rdbDrawcycle.Checked == true)
                {
                    // nếu chuột đang giữ và đang kéo thả một cái j đó (hình tròn)
                    if (isDragging == true)
                    {
                        Selectcycle.I = e.Location;
                        Refresh();
                    }
                }
                else if (isDragging == true)
                {
                    buffline.B = e.Location;
                    // đang kéo cái đuôi của đoạn thẳng
                    Selectcycle = clickedcycle(e.Location);
                    if (Selectcycle!=null)
                    {
                        // chuột đang ở trên một đường tròn
                        buffline.B = Selectcycle.I;
                    }
                }
            }
            Refresh();
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (rdbDrawline.Checked == true)
            {
                // đang vẽ đường thẳng
                Selectcycle = clickedcycle(e.Location);
                
                if (Selectcycle!=null&&buffline.A.X>0&&buffline.A!=Selectcycle.I&&Selectcycle.FindRef(cycleA)==-1)
                {
                    // thả chuột tại vị trí của 1 đường tròn
                    Selectcycle.Ref.Add(cycleA);
                    cycleA.Ref.Add(Selectcycle);
                    buffline.Tonotline();
                }
                else
                {
                    //thả chuột tại vị trí lung tung
                    
                    buffline.Tonotline();
                }
                Refresh();
            }
            Mouseisdown = false;
            isDragging = false;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            if (rdbremoveline.Checked == true)
            {
                try
                {
                    Selectedcycle.Color = Color.Blue;
                    Selectedline.cl = Color.Blue;
                    Selectcycle.Color = Color.Blue;
                    Selectcycle = null;
                    Selectedcycle = null;
                    Selectedline = null;
                }
                catch { }
                Selectedcycle = clickedcycle(e.Location);
                if (Selectedcycle != null)
                {
                    Selectedcycle.Color = Color.Red;
                }
                else
                {
                    Selectedline = clickline(e.Location);
                    if (Selectedline != null)
                    {
                        Selectedline.cl = Color.Red;
                    }
                }
                Refresh();
            }
        }

      
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show(e.KeyChar.ToString());
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            if (rdbremoveline.Checked == true  && (Selectedline != null || Selectedcycle!=null))
            {
                if (Selectedline != null)
                {
                    for (int i = 0; i < lstcycle.Count; i++)
                    {
                        if (lstcycle[i].I == Selectedline.A || lstcycle[i].I == Selectedline.B)
                        {
                            for (int j = i + 1; j < lstcycle.Count; j++)
                            {
                                if (lstcycle[j].I == Selectedline.A || lstcycle[j].I == Selectedline.B)
                                {
                                    lstcycle[j].Ref.Remove(lstcycle[i]);
                                    lstcycle[i].Ref.Remove(lstcycle[j]);
                                    Selectedline = null;
                                    return;
                                }
                            }
                        }
                    }
                    Selectedline = null;
                }
                else
                {
                    lstcycle.Remove(Selectedcycle);
                    foreach (var item in Selectedcycle.Ref)
                    {
                        item.Ref.Remove(Selectedcycle);
                    }
                    Selectedcycle = null;
                }
                Refresh();
            }
        }

        private void rdbremoveline_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbremoveline.Checked == false)
            {
                try
                {
                     Selectcycle.Color = Color.Blue;
                }
                catch { }
                try
                {
                    Selectedcycle.Color = Color.Blue;
                }
                catch { }
                try
                {
                    Selectedline.cl = Color.Blue;
                }
                catch { }
                Selectedline = null;
                Selectcycle = null;
                Selectedcycle = null;
                btn_xoa.Enabled = false;
            }
            else
            {
                btn_xoa.Enabled = true;
            }
            Refresh();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            Color[] cl = { Color.Black, Color.Blue, Color.Red, Color.Green, Color.Pink, Color.Violet, Color.Yellow };
            int mau;
            SolidBrush br = new SolidBrush(Color.Blue);
            Graphics gr = CreateGraphics();
            for (int item1 = 0; item1 < lstcycle.Count; item1++)
            {
                mau = 0;
                for (int item2 = 0; item2 < lstcycle[item1].Ref.Count;item2++ )
                {
                    
                    if (lstcycle[item1].Ref[item2].datomau == true &&lstcycle[item1].Ref[item2].Color == cl[mau])
                    {
                        mau++;
                        item2 = -1;
                    }
                }
                lstcycle[item1].Color = cl[mau];
                lstcycle[item1].datomau = true;
                br.Color = lstcycle[item1].Color;
                gr.FillEllipse(br, lstcycle[item1].I.X - lstcycle[item1].R, lstcycle[item1].I.Y - lstcycle[item1].R, lstcycle[item1].R * 2, lstcycle[item1].R * 2);
                Thread.Sleep(1000);
            }
            foreach (cycle item in lstcycle)
            {
                foreach (cycle item1 in item.Ref)
                {
                    item1.datomau = false;
                    item.Color = Color.Blue;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lstcycle.Clear();

            Selectcycle = new cycle();
            cycleA = new cycle();

            Selectedline = new line();
            Selectedcycle = new cycle();

            buffline = new line();
            lstcycle = new List<cycle>();

            isDragging = false;
            Mouseisdown = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start(@"Help.docx");
        }

        
    }
}
