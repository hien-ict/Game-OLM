﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace AI
{
    /// <summary>
    /// class này mô tả một đoạn thẳng chứ không phải một đường thẳng
    /// </summary>
    public class line
    {
        private Point a;
        private Point b;
        public Color cl;

        public int Hs_a
        {
            get { return A.Y - B.Y; }
        }

        public int Hs_b
        {
            get { return B.X - A.X; }
        }

        public int Hs_c
        {
            get { return -Hs_a * A.X - Hs_b * A.Y; }
        }

        public Point A
        {
            get { return a; }
            set { a = value; }
        }

        public Point B
        {
            get { return b; }
            set { b = value; }
        }

        /// <summary>
        /// thuộc tính này yêu cầu tính toán nhiều, nên sử dụng buffer để tăng hiệu suất
        /// </summary>
        public int dodai
        {
            get { return Convert.ToInt32((Math.Sqrt(Math.Pow(B.X - A.X, 2) + Math.Pow(B.Y - A.Y, 2)))); }
        }

        /// <summary>
        /// các thông số mặc định đều = 1, Graphic = null, color = blue
        /// </summary>
        public line()
        {
            A = new Point(-1, -1);
            B = new Point(-2, -2);
        }

        public line(line a)
        {
            A = a.A;
            B = a.B;
            cl = Color.Blue;
        }
        public line(Point p1, Point p2)
        {
            A = p1; B = p2;
            cl = Color.Blue;
        }

        public int Khoangcachden(Point p)
        {
            if (Hs_a == 0)
            {
                return Math.Abs(A.Y - p.Y);
            }
            else if (Hs_b == 0)
            {
                return Math.Abs(A.X - p.X);
            }
            return Convert.ToInt32((Math.Abs(Hs_a * p.X + Hs_b * p.Y + Hs_c) / (Math.Sqrt(Math.Pow(Hs_a, 2) + Math.Pow(Hs_b, 2)))));
        }

        public bool testpoint(Point p)
        {
            if (Hs_a * p.X + Hs_b * p.Y + Hs_c == 0)
            {
                if ((A.X <= p.X && B.X >= p.X) || (A.X >= p.X && B.X <= p.X))
                {
                    if ((A.Y <= p.Y && B.Y >= p.Y) || (A.Y >= p.Y && B.Y <= p.Y))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public bool isline()
        {
            if (A != B)
            {
                return true;
            }
            return false;
        }

        public void Tonotline()
        {
            A = new Point(-1, -1);
            B = new Point(-1, -1);
        }

        public void Show(Graphics gr)
        {
            gr.DrawLine(new Pen(cl), A, B);
        }
        public override string ToString()
        {
            return a.ToString() + b.ToString();
        }
       
    }
}
