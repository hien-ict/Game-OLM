﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI
{
    class node
    {
        List<int> relation = new List<int>();
        //public void node()
        //{

        //}
    }
}
