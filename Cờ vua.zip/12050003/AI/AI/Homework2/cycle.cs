﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace AI
{
    public class cycle
    {

        public List<cycle> Ref;
        // class đường tròn được thiết kế theo phương trình tổng quát : x^2 + y^2 + 2ax + 2by +c =0;
        // xác định khi có tâm và bán kính

        // ----------------------------------------------- field
        private int _r;
        private Point _i;
        private Color _cl;
        public bool datomau;
        public int R
        {
            
            get { return _r; }
            set { _r = value; }
        }

        public Point I
        {
            get { return _i; }
            set { _i = value; }
        }

        public Color Color
        {
            get { return _cl; }
            set { _cl = value; }
        }



        public int Hs_a
        {
            get { return -_i.X; }
        }

        public int Hs_b
        {
            get { return -_i.Y; }
        }

        public int Hs_c
        {
            get { return I.X * I.X + I.Y * I.Y - R * R; }
        }


        // ------------------------------------------------------- constructor
        public cycle(Point i, int r, Color cl)
        {
            I = i;
            R = r;
            Color = cl;
            Ref = new List<cycle>();
            datomau = false;
        }
        //public class compare : IComparer<cycle>
        //{
        //    public compare()
        //    {

        //    }
        //    public bool Compare(cycle a, cycle b)
        //    {
        //        if (a.Ref.Count >= b.Ref.Count)
        //        {
        //            return true;
        //        }
        //        return false;
        //    }    
        //}
        
        /// <summary>
        /// các thông số mặc định  đều bằng 1, graphic = null, color = Blue
        /// </summary>
        public cycle()
        {
            I = new Point(-5, -5);
            R = 0;
            Color = Color.Blue;
            Ref = new List<cycle>();
            datomau = false;
        }

        public cycle RemoveRef(line Refe)
        {
            if (Refe.A!=I&&Refe.B!=I)
            {
                return null;
            }
            foreach (cycle item in this.Ref)
            {
                if (item.I==Refe.A||item.I==Refe.B)
                {
                    return item;
                }
            }
            return null;
        }

        

        public void show(Graphics gr)
        {
            gr.DrawEllipse(new Pen(Color), I.X - R, I.Y - R, R * 2, R * 2);
            Pen p = new Pen(Color.Blue);
            foreach (cycle item in Ref)
            {
                gr.DrawLine(p, I, item.I);
            }
        }

        public void hide(Graphics gr)
        {
            gr.DrawEllipse(Pens.White, I.X - R, I.Y - R, R * 2, R * 2);
        }

        public void Tonotycle()
        {
            R = 0;
        }

        /// <summary>
        /// trả về 0 nếu ngoài đường tròn, 1 nếu nằm trên đường tròn, 2 nếu nằm trong, 3 nếu trùng với tâm.
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public int vitri(Point p)
        {
            int khoangcach = Convert.ToInt32(Math.Sqrt((p.X - I.X) * (p.X - I.X) + (p.Y - I.Y) * (p.Y - I.Y)));
            if (khoangcach>R)
            {
                return 0;
            }
            else if (khoangcach==R)
            {
                return 1;
            }
            else if (khoangcach<R)
            {
                return 2;
            }
            return 3;
        }

        public int FindRef(cycle a)
        {
            for (int i = 0; i< Ref.Count; i++)
            {
                if (Ref[i].I==a.I)
                {
                    return i;
                }
            }
            return -1;
        }

        
        public override string ToString()
        {
            return "I=" + I.ToString() + " R = " + R.ToString();
        }

        ~cycle()
        {
            Ref.Clear();
        }
    }
}
