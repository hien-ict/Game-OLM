﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace AI.Homework3
{
    public partial class Water : Form
    {
        WaterBox Box1;
        WaterBox Box2;

        public Water()
        {
            InitializeComponent();
            Box1 = new WaterBox(progressBar1, label5,numericUpDown1);
            Box2 = new WaterBox(progressBar2, label4,numericUpDown2);
        }

        private void Water_Load(object sender, EventArgs e)
        {

        }

        void LogClear()
        {
            richTextBox1.Text = string.Empty;
        }

        void AddLog(string newlog)
        {
            richTextBox1.Text = newlog + Environment.NewLine + richTextBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Box1.IsFulled)
            {
                Box1.Clear();
                AddLog("Đổ hết nước bình 1 đi");
                return;
            }
            if (Box2.IsEmpty)
            {
                Box2.Getfull();
                AddLog("Đong đầy nước bình 2");
                return;
            }
            if (!Box1.IsFulled && !Box2.IsEmpty)
            {
                Box2.Flowto(Box1);
                AddLog("Đổ nước từ bình 2 sang bình 1");
                return;
            }
        }

        bool checkFinished()
        {
            
            if (Box1.WaterLevel == numericUpDown3.Value || Box2.WaterLevel == numericUpDown3.Value)
            {
                AddLog("Hoàn thành");
                return true;
            }
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Box1.MaxWaterlevel = 0;
            Box2.MaxWaterlevel = 0;
            LogClear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if ( numericUpDown3.Value % ucln(Box1.MaxWaterlevel,Box2.MaxWaterlevel) != 0 )
            {
                MessageBox.Show("Không thỏa mãn điều kiện, không thể tính, xem điều kiện trong View help");
                return;
            }
            LogClear();
            this.Focus();
            while(!checkFinished())
            {
                button1_Click(this, new EventArgs());
            }
        }

        int ucln(int a, int b)
        {
            return b != 0? ucln(b, a % b) : a;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            this.Focus();
            MessageBox.Show(ucln(Box1.MaxWaterlevel, Box2.MaxWaterlevel).ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process.Start("Help1.docx");
        }
    }
}
