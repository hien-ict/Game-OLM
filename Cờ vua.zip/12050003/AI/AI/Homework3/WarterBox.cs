﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AI.Homework3
{
    public class WaterBox
    {
        public ProgressBar FX_PRGcurrent;
        public Label FX_LBCurent;
        public NumericUpDown FX_Max;



        private int waterlevel;

        public int WaterLevel
        {
            get { return waterlevel; }
            set
            {
                waterlevel = value;
                if (waterlevel > maxWaterlevel)
                {
                    waterlevel = maxWaterlevel;
                }
                if (waterlevel < 0)
                {
                    WaterLevel = 0;
                }
                FX_LBCurent.Text = WaterLevel.ToString();
                FX_PRGcurrent.Value = WaterLevel;
            }
        }

        private int maxWaterlevel;

        public int MaxWaterlevel
        {
            get { return maxWaterlevel; }
            set
            {
                maxWaterlevel = value;
                if (maxWaterlevel < waterlevel)
                {
                    WaterLevel = maxWaterlevel;
                }
                FX_PRGcurrent.Maximum = MaxWaterlevel;
                FX_Max.Value = MaxWaterlevel;
            }
        }

        public WaterBox(ProgressBar bar, Label curent, NumericUpDown Max)
        {
            FX_LBCurent = curent;
            FX_Max = Max;
            FX_PRGcurrent = bar;
            MaxWaterlevel = 0;
            WaterLevel = 0;

            FX_Max.ValueChanged += delegate(object sender, EventArgs e)
            {
                MaxWaterlevel = (int)FX_Max.Value;
            };

        }

        public bool IsFulled
        {
            get { return WaterLevel == MaxWaterlevel; }
        }

        public bool IsEmpty
        {
            get { return WaterLevel == 0; }
        }

        public void Flowto(WaterBox destiny)
        {
            int thieu = destiny.MaxWaterlevel - destiny.WaterLevel;
            destiny.Addwater(WaterLevel);
            WaterLevel = WaterLevel - thieu;
        }

        public void Addwater(int newwaterlevel)
        {
            WaterLevel += newwaterlevel;   
        }

        public void Clear()
        {
            WaterLevel = 0;
        }

        public void Getfull()
        {
            WaterLevel = MaxWaterlevel;
        }

    }
}
