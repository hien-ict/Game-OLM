﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI.Homework1
{
    public class Machine
    {
        public List<Congviec> Jobs;
        public float Sumtime;

        // công suất của máy, nếu giá trị càng cao, máy càng mạnh
        public float Power;
        public Machine(float starttime, float power)
        {
            Sumtime = starttime;
            Power = power;
            Jobs = new List<Congviec>();
        }
        public Machine()
        {
            Sumtime = 0;
            Jobs = new List<Congviec>();
        }
    }
}
