﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AI.Homework1
{
    public class Congviec
    {
        public float Processtime;
        public float Thutu;
        public bool Daduocphan;
        public int stt;
        public Congviec(float processtime, float thutu)
        {
            Processtime = processtime;
            Thutu = thutu;
            Daduocphan = false;

        }
    }
}
