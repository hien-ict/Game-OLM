﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace AI.Homework1
{
    public partial class Chiacongviec : Form
    {
        List<Congviec> lstJobs = new List<Congviec>();
        List<Machine> lstMachines = new List<Machine>();

        Congviec selectedjob = null;
        Machine selectmachine = null;
        public Chiacongviec()
        {
            InitializeComponent();
        }

        private void Chiacongviec_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Vui lòng đọc kĩ phần Help trước khi sử dụng phần mềm" + Environment.NewLine + "Điều này quan trọng");
        }



        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                selectmachine = lstMachines[listBox1.SelectedIndex];
                updow_m_starttime.Value = (decimal)selectmachine.Sumtime;
                numericUpDown1.Value = (decimal)selectmachine.Power;
            }
            catch { };
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd1_Click(object sender, EventArgs e)
        {
            lstMachines.Add(new Machine((float)updow_m_starttime.Value, (float)numericUpDown1.Value));
            listBox1.Items.Add(updow_m_starttime.Value.ToString() + " and " + numericUpDown1.Value.ToString());
            label5.Text = "Tổng số máy : " + lstMachines.Count.ToString();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnremove1_Click(object sender, EventArgs e)
        {
            lstMachines.RemoveAt(listBox1.SelectedIndex);
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            try
            {
                listBox1.SelectedIndex = 0;
            }
            catch { };
            label5.Text = "Tổng số máy : " + lstMachines.Count.ToString();

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                selectedjob = lstJobs[listBox2.SelectedIndex];
                updow_c_time.Value = (decimal)selectedjob.Processtime;
                updow_c_thutu.Value = (decimal)selectedjob.Thutu;

            }
            catch { };
        }

        private void btnadd2_Click(object sender, EventArgs e)
        {
            lstJobs.Add(new Congviec((float)updow_c_time.Value, (float)updow_c_thutu.Value));
            listBox2.Items.Add(updow_c_time.Value.ToString() + " and " + updow_c_thutu.Value.ToString());
            label6.Text = "Tổng số công việc : " + lstJobs.Count.ToString();
        }

        private void btnremove2_Click(object sender, EventArgs e)
        {
            lstJobs.RemoveAt(listBox2.SelectedIndex);
            listBox2.Items.RemoveAt(listBox2.SelectedIndex);
            try
            {
                listBox2.SelectedIndex = 0;
            }
            catch { };
            label6.Text = "Tổng số công việc : " + lstJobs.Count.ToString();
        }

        private void btn_m_Save_Click(object sender, EventArgs e)
        {
            try
            {
                lstMachines[listBox1.SelectedIndex].Sumtime = (float)updow_m_starttime.Value;
                lstMachines[listBox1.SelectedIndex].Power = (float)numericUpDown1.Value;
                listBox1.Items[listBox1.SelectedIndex] = updow_m_starttime.Value.ToString() + " and " + numericUpDown1.Value.ToString();
            }
            catch { };
        }

        private void btn_c_save_Click(object sender, EventArgs e)
        {
            lstJobs[listBox2.SelectedIndex].Processtime = (float)updow_c_time.Value;
            lstJobs[listBox2.SelectedIndex].Thutu = (float)updow_c_thutu.Value;
            listBox2.Items[listBox2.SelectedIndex] = updow_c_time.Value.ToString() + " and " + updow_c_thutu.Value.ToString();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstJobs.Count; i++)
            {
                lstJobs[i].stt = i;
            }

            // sắp xếp các công việc theo thứ tự
            // nếu cùng thứ tự, việc nào dài hơn thì xếp trước, ngắn hơn xếp sau
            Congviec temp;
            for (int i = 0; i < lstJobs.Count; i++)
            {
                for (int j = i; j < lstJobs.Count; j++)
                {
                    if (lstJobs[i].Thutu > lstJobs[j].Thutu)
                    { // sai thứ tự
                        temp = lstJobs[i];
                        lstJobs[i] = lstJobs[j];
                        lstJobs[j] = temp;
                    }
                    else if (lstJobs[i].Thutu == lstJobs[j].Thutu && lstJobs[i].Processtime < lstJobs[j].Processtime)
                    { // cùng thứ tự nhưng thời gian không đúng vị trí
                        temp = lstJobs[i];
                        lstJobs[i] = lstJobs[j];
                        lstJobs[j] = temp;
                    }
                }
            }


            float max = 0;// giá trị dùng để xác định thời gian thực hiện hết giai đoạn hiện hành
            Machine minmachine; // máy có thời gian làm việc í tnhất

            for (int i = 0; i < lstJobs.Count; i++)
            {// duyệt từ đầu đến cuối danh sách công việc.
                // với mỗi lần lặp, một công việc sẽ được phân cho 1 máy

                minmachine = Minmachine(lstJobs[i].Processtime); // lấy máy có thời gian ngắn nhất
                minmachine.Sumtime += lstJobs[i].Processtime / minmachine.Power;// cộng thêm thời gian vừa được phân công chia cho công suất của máy
                minmachine.Jobs.Add(lstJobs[i]); // thêm vào danh sách công việc của máy
                if (max < minmachine.Sumtime)
                {// xác định lại max
                    max = minmachine.Sumtime;
                }
                if ((i < lstJobs.Count - 1) && (lstJobs[i].Thutu < lstJobs[i + 1].Thutu))
                {// đến cuối đoạn
                    // đến đây, các máy đã xong công việc rồi thì thời gian của máy trong đoạn sau là 0
                    // nếu làm chưa xong thì thời gian của máy đó sẽ kéo dài qua đoạn sau
                    foreach (Machine item in lstMachines)
                    {
                        if (item.Sumtime > max)
                        {// bị trồi lên qua max
                            item.Sumtime -= max;
                        }
                        else item.Sumtime = 0;
                    }
                }
            }
            showreport();
            foreach (Machine item in lstMachines)
            {
                item.Jobs.Clear();
            }
        }

        private void showreport()
        {
            string report = string.Empty;
            for (int i = 0; i < lstMachines.Count; i++)
            {
                report += "Máy " + i.ToString() + ": ";
                foreach (var item in lstMachines[i].Jobs)
                {
                    report += " + " +  item.stt.ToString();
                }
                report += Environment.NewLine;
            }
            MessageBox.Show(report);
            report = string.Empty;
        }
        private Machine Minmachine(float time)
        {
            Machine min = lstMachines[0];
            foreach (Machine item in lstMachines)
            {
                if (min.Sumtime + (time / min.Power)> item.Sumtime+ (time / item.Power))
                {// thời gian nếu thực hiện của min > của item
                    min = item;
                }
            }
            return min;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start("Help2.docx");
        }

        private void updow_m_power_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
