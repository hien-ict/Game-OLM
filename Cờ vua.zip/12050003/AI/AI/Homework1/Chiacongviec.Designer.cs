﻿namespace AI.Homework1
{
    partial class Chiacongviec
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_m_Save = new System.Windows.Forms.Button();
            this.updow_m_starttime = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnadd1 = new System.Windows.Forms.Button();
            this.btnremove1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_c_save = new System.Windows.Forms.Button();
            this.updow_c_thutu = new System.Windows.Forms.NumericUpDown();
            this.updow_c_time = new System.Windows.Forms.NumericUpDown();
            this.btnadd2 = new System.Windows.Forms.Button();
            this.btnremove2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updow_m_starttime)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updow_c_thutu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.updow_c_time)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(196, 19);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(142, 251);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.btn_m_Save);
            this.groupBox1.Controls.Add(this.updow_m_starttime);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnadd1);
            this.groupBox1.Controls.Add(this.btnremove1);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(344, 288);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Máy";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_m_Save
            // 
            this.btn_m_Save.Location = new System.Drawing.Point(56, 200);
            this.btn_m_Save.Name = "btn_m_Save";
            this.btn_m_Save.Size = new System.Drawing.Size(75, 23);
            this.btn_m_Save.TabIndex = 8;
            this.btn_m_Save.Text = "Save";
            this.btn_m_Save.UseVisualStyleBackColor = true;
            this.btn_m_Save.Click += new System.EventHandler(this.btn_m_Save_Click);
            // 
            // updow_m_starttime
            // 
            this.updow_m_starttime.Location = new System.Drawing.Point(73, 40);
            this.updow_m_starttime.Name = "updow_m_starttime";
            this.updow_m_starttime.Size = new System.Drawing.Size(120, 20);
            this.updow_m_starttime.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Power";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "start time";
            // 
            // btnadd1
            // 
            this.btnadd1.Location = new System.Drawing.Point(100, 247);
            this.btnadd1.Name = "btnadd1";
            this.btnadd1.Size = new System.Drawing.Size(75, 23);
            this.btnadd1.TabIndex = 2;
            this.btnadd1.Text = "Add";
            this.btnadd1.UseVisualStyleBackColor = true;
            this.btnadd1.Click += new System.EventHandler(this.btnadd1_Click);
            // 
            // btnremove1
            // 
            this.btnremove1.Location = new System.Drawing.Point(6, 247);
            this.btnremove1.Name = "btnremove1";
            this.btnremove1.Size = new System.Drawing.Size(75, 23);
            this.btnremove1.TabIndex = 1;
            this.btnremove1.Text = "Remove";
            this.btnremove1.UseVisualStyleBackColor = true;
            this.btnremove1.Click += new System.EventHandler(this.btnremove1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_c_save);
            this.groupBox2.Controls.Add(this.updow_c_thutu);
            this.groupBox2.Controls.Add(this.updow_c_time);
            this.groupBox2.Controls.Add(this.btnadd2);
            this.groupBox2.Controls.Add(this.btnremove2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.listBox2);
            this.groupBox2.Location = new System.Drawing.Point(385, 36);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(344, 288);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Công việc";
            // 
            // btn_c_save
            // 
            this.btn_c_save.Location = new System.Drawing.Point(60, 200);
            this.btn_c_save.Name = "btn_c_save";
            this.btn_c_save.Size = new System.Drawing.Size(75, 23);
            this.btn_c_save.TabIndex = 9;
            this.btn_c_save.Text = "Save";
            this.btn_c_save.UseVisualStyleBackColor = true;
            this.btn_c_save.Click += new System.EventHandler(this.btn_c_save_Click);
            // 
            // updow_c_thutu
            // 
            this.updow_c_thutu.Location = new System.Drawing.Point(70, 123);
            this.updow_c_thutu.Name = "updow_c_thutu";
            this.updow_c_thutu.Size = new System.Drawing.Size(120, 20);
            this.updow_c_thutu.TabIndex = 9;
            // 
            // updow_c_time
            // 
            this.updow_c_time.Location = new System.Drawing.Point(70, 58);
            this.updow_c_time.Name = "updow_c_time";
            this.updow_c_time.Size = new System.Drawing.Size(120, 20);
            this.updow_c_time.TabIndex = 8;
            // 
            // btnadd2
            // 
            this.btnadd2.Location = new System.Drawing.Point(102, 247);
            this.btnadd2.Name = "btnadd2";
            this.btnadd2.Size = new System.Drawing.Size(75, 23);
            this.btnadd2.TabIndex = 5;
            this.btnadd2.Text = "Add";
            this.btnadd2.UseVisualStyleBackColor = true;
            this.btnadd2.Click += new System.EventHandler(this.btnadd2_Click);
            // 
            // btnremove2
            // 
            this.btnremove2.Location = new System.Drawing.Point(8, 247);
            this.btnremove2.Name = "btnremove2";
            this.btnremove2.Size = new System.Drawing.Size(75, 23);
            this.btnremove2.TabIndex = 4;
            this.btnremove2.Text = "Remove";
            this.btnremove2.UseVisualStyleBackColor = true;
            this.btnremove2.Click += new System.EventHandler(this.btnremove2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Thứ tự";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Time";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(196, 19);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(142, 251);
            this.listBox2.TabIndex = 0;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(336, 352);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(75, 23);
            this.btnProcess.TabIndex = 8;
            this.btnProcess.Text = "process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(94, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Tổng số máy : 0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(504, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tổng số công việc : 0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(674, 352);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "View Help";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(70, 104);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 9;
            // 
            // Chiacongviec
            // 
            this.AcceptButton = this.btnadd2;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 387);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Chiacongviec";
            this.Text = "Chiacongviec";
            this.Load += new System.EventHandler(this.Chiacongviec_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updow_m_starttime)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updow_c_thutu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.updow_c_time)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnadd1;
        private System.Windows.Forms.Button btnremove1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnadd2;
        private System.Windows.Forms.Button btnremove2;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.NumericUpDown updow_m_starttime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown updow_c_thutu;
        private System.Windows.Forms.NumericUpDown updow_c_time;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_m_Save;
        private System.Windows.Forms.Button btn_c_save;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;


    }
}