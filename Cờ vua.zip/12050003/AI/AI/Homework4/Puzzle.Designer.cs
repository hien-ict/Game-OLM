﻿namespace AI.Homework4
{
    partial class Puzzle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ptb_Next = new System.Windows.Forms.PictureBox();
            this.ptb_prev = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_Next)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_prev)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Black;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.ForeColor = System.Drawing.Color.DarkOrange;
            this.textBox1.Location = new System.Drawing.Point(12, 266);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 13);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "0";
            this.textBox1.Visible = false;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ptb_Next
            // 
            this.ptb_Next.Location = new System.Drawing.Point(210, 286);
            this.ptb_Next.Name = "ptb_Next";
            this.ptb_Next.Size = new System.Drawing.Size(44, 40);
            this.ptb_Next.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptb_Next.TabIndex = 3;
            this.ptb_Next.TabStop = false;
            this.ptb_Next.Click += new System.EventHandler(this.ptb_Next_Click);
            // 
            // ptb_prev
            // 
            this.ptb_prev.Location = new System.Drawing.Point(76, 286);
            this.ptb_prev.Name = "ptb_prev";
            this.ptb_prev.Size = new System.Drawing.Size(44, 40);
            this.ptb_prev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptb_prev.TabIndex = 4;
            this.ptb_prev.TabStop = false;
            this.ptb_prev.Click += new System.EventHandler(this.ptb_prev_Click);
            // 
            // Puzzle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 338);
            this.Controls.Add(this.ptb_prev);
            this.Controls.Add(this.ptb_Next);
            this.Controls.Add(this.textBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Puzzle";
            this.Opacity = 0.9D;
            this.Text = "Puzzle";
            this.Load += new System.EventHandler(this.Puzzle_Load);
            this.SizeChanged += new System.EventHandler(this.Puzzle_SizeChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Puzzle_Paint);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Puzzle_KeyDown);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Puzzle_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.ptb_Next)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptb_prev)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox ptb_Next;
        private System.Windows.Forms.PictureBox ptb_prev;
    }
}