﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace AI.Homework4
{
    public partial class Puzzle : Customform
    {
        Status st = new Status(Typeconstructor.Arranged);

        List<Status> Way = new List<Status>();

        int watchingvalue;

        public Puzzle()
        {
            InitializeComponent();
            timer1.Start();
            new Customcontrol.Swaper(ptb_prev, Properties.Resources.prev1, Properties.Resources.prev2);
            new Customcontrol.Swaper(ptb_Next, Properties.Resources.next1, Properties.Resources.next2);
            
        }

        private void Puzzle_SizeChanged(object sender, EventArgs e)
        {
            textBox1.Visible = false;
            st.UpdateFormsize(Size);
            ptb_prev.Location = new Point(Status.Left + Status.Unitsize.Height,Status.Top + (Status.Unitsize.Height*3));
            ptb_prev.Size = new Size(Status.Unitsize.Height / 3, Status.Unitsize.Height / 3);
            ptb_Next.Size = ptb_prev.Size;
            ptb_Next.Top = ptb_prev.Top;
            ptb_Next.Left = Status.Right - ptb_prev.Size.Height - Status.Unitsize.Height;
            Refresh();
        }

        private void Puzzle_Load(object sender, EventArgs e)
        {
            MessageBox.Show("trước khi chơi, Hãy ấn F1 để xem Help");
            st.UpdateFormsize(Size);
            Refresh();
        }

        private void Puzzle_Paint(object sender, PaintEventArgs e)
        {
            st.Show(e.Graphics);
        }

        private void Puzzle_MouseClick(object sender, MouseEventArgs e)
        {
            //kiểm tra các lỗi có thể phát sinh
            Index clickedindex = Status.IndexfromPoint(e.Location);
            if (clickedindex==null || st.Map[clickedindex.I,clickedindex.J]==0)
            {
                textBox1.Visible = false;
                textBox1.Enabled = false;
                return;
            }
            textBox1.Tag = clickedindex;
            Point location = Status.LocationfromIndex(clickedindex.I, clickedindex.J);
            // click vào 1 ô, hiển thị textbox tại ô vừa click
            textBox1.Text = st.Map[clickedindex.I, clickedindex.J].ToString();
            textBox1.Font = new Font("Segoe UI", Status.Unitsize.Height / 6, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            textBox1.Location = new Point(location.X + Status.Unitsize.Height / 2 - Status.Unitsize.Height / 8, location.Y + Status.Unitsize.Height / 2 - Status.Unitsize.Height / 8);
            textBox1.Width = (int)textBox1.Font.Size+1;
            textBox1.Visible = true;
            textBox1.Enabled = true;
            textBox1.Focus();
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar>47 && e.KeyChar <57)
            {
                number = e.KeyChar.ToString();
            }
        }

        string number = "k";

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (number!="k")
            {
                textBox1.Text = number;
                number = "k";
                if (st.Map[((Index)textBox1.Tag).I, ((Index)textBox1.Tag).J].ToString()!= textBox1.Text)
                { // số đã bị thay đổi
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            if (st.Map[i,j].ToString() == textBox1.Text)
                            {
                                st.Map[i, j] = st.Map[((Index)textBox1.Tag).I, ((Index)textBox1.Tag).J];
                                st.Map[((Index)textBox1.Tag).I, ((Index)textBox1.Tag).J] = int.Parse(textBox1.Text);
                                Way = new List<Status>();
                                watchingvalue = 0;
                                st.G = 0;
                                i = 3;
                                break;
                            }
                        }
                    }
                    Refresh();
                }
            }
            else
            {
                textBox1.Text = st.Map[((Index)textBox1.Tag).I, ((Index)textBox1.Tag).J].ToString();
            }
            
        }

        private void Puzzle_KeyDown(object sender, KeyEventArgs e)
        {
            Status buff = new Status(Typeconstructor.Null);
            switch (e.KeyCode)
            {
                case Keys.Up:
                    {
                        buff = st.GetUp();
                        Way = new List<Status>();
                        watchingvalue = 0;
                    }; break;
                case Keys.Down:
                    {
                        buff = st.GetDown();
                        Way = new List<Status>();
                        watchingvalue = 0;
                    }; break;
                case Keys.Left:
                    {
                        buff = st.GetLeft();
                        Way = new List<Status>();
                        watchingvalue = 0;
                    }; break;
                case Keys.Right:
                    {
                        buff = st.GetRight();
                        Way = new List<Status>();
                        watchingvalue = 0;
                    }; break;
                case Keys.F1:
                    {
                        Process.Start("Help3.docx");
                        buff = st;
                    } break;
                default : 
                     buff = null;break;
            }
            if (buff != null)
            {
                st = buff;
                Refresh();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }

        private void ptb_Next_Click(object sender, EventArgs e)
        {
            if (Way.Count==0)
            {
                Way = AI.AStar(st);
                watchingvalue = Way.Count-1;
                st = Way[watchingvalue];
                watchingvalue--;
            }
            else
            {
                if (watchingvalue!=-1)
                {
                    st = Way[watchingvalue];
                    watchingvalue--;
                }
            }

            Refresh();
        }

        private void ptb_prev_Click(object sender, EventArgs e)
        {
            if (watchingvalue!=0)
            {
                watchingvalue++;
                st = Way[watchingvalue];
            }
        }        
    }
}
