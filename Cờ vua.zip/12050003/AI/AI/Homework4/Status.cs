﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
namespace AI.Homework4
{
    public class Status
    {
        static Random rd = new Random();

        static int[,] origin = new int[,] { { 1, 2, 3 }, { 8, 0, 4 }, { 7, 6, 5 } };

        public static int Top;
        public static int Left;
        public static Size Unitsize;



        Index Hole;

        public int[,] _map;
        public int[,] Map
        {
            get { return _map; }
            set { 
                _map = value; 
            }
        }

        public int H
        {
            get { return Rate(this); }
        }

        public int G;

        public int F;

        public Status Father;

        public int ID;

        public void GetID()
        {
            ID = 0;
            int n = 1;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    ID += Map[i, j] * n;
                    n *= 10;
                }
        }

      
        public override bool Equals(object obj)
        {
            if (ID == ((Status)obj).ID)
            {
                return true;
            }
            return false;
        }

        public Status(Typeconstructor type)
        {
            if (type == Typeconstructor.Arranged)
            {
                Map = new int[,] { { 1, 2, 3 }, { 8, 0, 4 }, { 7, 6, 5 } };
                Hole = new Index(1, 1);
            }
            else
            {
                Map = new int[3, 3];
            }
            GetID();
        }

       

        
        public Status Getcopy()
        {
            Status rtstatus = new Status(Typeconstructor.Null);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    rtstatus.Map[i, j] = Map[i, j];
                }
            }
            rtstatus.Hole = Hole.GetCopy();
            rtstatus.G = G;
            rtstatus.Father = Father;
            rtstatus.ID = ID;
            return rtstatus;
        }


        public Status GetUp()
        {
            if (Hole.I==2)
            {
                return null;
            }

            Status rtstatus = this.Getcopy();
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = rtstatus.Map[rtstatus.Hole.I + 1, rtstatus.Hole.J];
            rtstatus.Hole.I++;
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = 0;
            rtstatus.GetID();
            return rtstatus;
        }

        public Status GetDown()
        {
            if (Hole.I==0)
            {
                return null;
            }

            Status rtstatus = this.Getcopy();
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = rtstatus.Map[rtstatus.Hole.I - 1, rtstatus.Hole.J];
            rtstatus.Hole.I--;
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = 0;
            rtstatus.GetID();
            return rtstatus;
        }

        public Status GetLeft()
        {
            if (Hole.J == 2)
            {
                return null;
            }

            Status rtstatus = this.Getcopy();
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J + 1];
            rtstatus.Hole.J++;
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = 0;
            rtstatus.GetID();
            return rtstatus;
        }

        public Status GetRight()
        {
            if (Hole.J == 0)
            {
                return null;
            }

            Status rtstatus = this.Getcopy();
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J - 1];
            rtstatus.Hole.J--;
            rtstatus.Map[rtstatus.Hole.I, rtstatus.Hole.J] = 0;
            rtstatus.GetID();
            return rtstatus;
        }


        // ------------------------- Completed ----------------------

        public List<Status> GetallChildren()
        {
            List<Status> rtlst = new List<Status>();

            Status buff = GetUp();
            if (buff != null)
            {
                rtlst.Add(buff);
            }

            buff = GetDown();
            if (buff != null)
            {
                rtlst.Add(buff);
            }

            buff = GetLeft();
            if (buff != null)
            {
                rtlst.Add(buff);
            }

            buff = GetRight();
            if (buff != null)
            {
                rtlst.Add(buff);
            }
            return rtlst;
        }

        public void UpdateFormsize(Size newFormsize)
        {
            if (newFormsize.Height < newFormsize.Width)
            {
                Unitsize = new Size(newFormsize.Height / 4, newFormsize.Height / 4);
            }
            else
            {
                Unitsize = new Size(newFormsize.Width / 4, newFormsize.Width / 4);
            }
            Top = newFormsize.Height / 2 - Unitsize.Height / 2 - Unitsize.Height;
            Left = newFormsize.Width / 2 - Unitsize.Height / 2 - Unitsize.Height;
        }


        public static int Rate(Status st)
        {
            int rtvl = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (st.Map[i, j] != origin[i, j])
                    {
                        rtvl++;
                    }
                }
            }
            return rtvl;
        }



        public void Show(Graphics gr)
        {
            Size buff = new Size(Unitsize.Height - 1, Unitsize.Height - 1);
            Font font = new Font("Segoe UI", Unitsize.Height/6, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Point location = new Point();
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (Map[i,j]!=0)
                    {
                        location = LocationfromIndex(i, j);
                        gr.FillRectangle(Brushes.Black, new Rectangle(location, buff));
                        gr.DrawString(Map[i, j].ToString(), font, Brushes.White, new Point(location.X + Unitsize.Height / 2 - Unitsize.Height / 8, location.Y + Unitsize.Height / 2 - Unitsize.Height / 8));    
                    }
                }
            }
        }

        /// <summary>
        /// trả về Index từ một điểm, nếu click sai vị trí, nó sẽ trả về null;
        /// </summary>
        /// <param name="ClickedPoint"></param>
        /// <returns></returns>
        public static Index IndexfromPoint(Point ClickedPoint)
        {
            if (ClickedPoint.X > Left && ClickedPoint.X < Right && ClickedPoint.Y > Top && ClickedPoint.Y < Bottom)
            {
                Index rtPoint = new Index();
                rtPoint.J = (ClickedPoint.X - Left) / Unitsize.Height;
                rtPoint.I = (ClickedPoint.Y - Top) / Unitsize.Height;
                return rtPoint;
            }
            return null;
        }

        public static Point LocationfromIndex(int i, int j)
        {
            return new Point(j * Unitsize.Width + Left, i * Unitsize.Height + Top);
        }


        public static int Right
        {
            get 
            {
                return Left + 3* Unitsize.Height;
            }
        }

        public static int Bottom 
        {
            get { return Top + 3 * Unitsize.Height; }
        }
    }

    public class Index
    {
        public int I,J;
        public override string ToString()
        {
            return "(" + I.ToString() + "," + J.ToString() + ")";
        }

        public Index(int i, int j)
        {
            I = i;
            J = j;
        }

        public Index()
        {

        }

        public Index GetCopy()
        {
            return new Index(I, J);
        }
    }

    public enum Typeconstructor
    {
        Null,
        Arranged,
    }

}
