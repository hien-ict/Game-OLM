﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AI.Homework4;

namespace AI
{
    public class AI
    {
        public static List<Status> AStar(Status root)
        {
            root.Father = null;
            root.G = 0;
            root.F = root.H;

            List<Status> Open = new List<Status>();
            List<Status> Close = new List<Status>();
            Open.Add(root);
            while(Open.Count!=0)
            {
                // B2.1
                Status p = Getmin(Open);

                // B2.2
                if (p.F == p.G )
                {// trạng thái kết thúc
                    List<Status> rtlst = new List<Status>();
                    do
                    {
                        rtlst.Add(p);
                        p = p.Father;
                    } while (p != null);
                    if (rtlst.Count!=1)
                    {
                        rtlst.RemoveAt(rtlst.Count - 1);
                    }
                    return rtlst;
                }

                //B2.3

                Close.Add(p);
                Open.Remove(p);

                List<Status> allchildren = p.GetallChildren();

                foreach (var q in allchildren)
                {
                    // thực ra, với bài toán này, hai trường hợp đầu tiên sẽ không bao giờ rơi vào
                    // Một node mới hoặc bị bỏ qua, hoặc được thêm vào Open ở trường hợp cuối
                    int index = Exited(Open,q);
                    if (index!=-1)
                    {// Đã có sẵn trong Open
                        if ( Open[index].G >p.G + 1)
                        {// thấy có đường ngắn hơn thông qua p
                            Open[index].G = p.G + 1;
                            Open[index].F = Open[index].G + Open[index].H;
                            Open[index].Father = p;
                        }
                    }
                    else
                    {
                        index = Exited(Close,q);
                        if (index!=-1)
                        { // đã có sẵn trong Close
                            if (Close[index].G > p.G + 1)
                            { // có thể đi đến một điểm trong close với đường ngắn hơn
                                Open.Add(Close[index]);
                                Close.RemoveAt(index);
                            }
                        }
                        else
                        {// không thuộc close lẫn ko thuộc open
                            q.G = p.G + 1;
                            q.F = q.G + q.H;
                            q.Father = p;
                            Open.Add(q);
                        }
                    }
                }
            }

            //Bước 3 :
            return null;
        }

        public static Status Getmin(List<Status> Source)
        {
            // hàm này yêu cầu source phải khác rỗng
            Status min = Source[0];
            for (int i = 0; i < Source.Count; i++)
            {
                if (min.F > Source[i].F)
                {
                    min = Source[i];
                }
            }
            return min;
        }

        public static int Exited(List<Status> source, Status compare)
        {
            for (int i = 0; i < source.Count; i++)
            {
                if (compare.Equals(source[i]))
                {
                    return i;
                }
            }
            return -1;
        }

    }
}
