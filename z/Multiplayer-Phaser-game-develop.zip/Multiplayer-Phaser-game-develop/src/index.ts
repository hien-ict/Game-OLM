import {PhaserSpaceGame} from './client/engine/phaser-engine.class';

new PhaserSpaceGame();