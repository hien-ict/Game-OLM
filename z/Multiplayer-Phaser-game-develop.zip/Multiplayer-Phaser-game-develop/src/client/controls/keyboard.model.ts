export interface Controls {
    cursors: Phaser.CursorKeys;
    fireWeapon: Phaser.Key;
}