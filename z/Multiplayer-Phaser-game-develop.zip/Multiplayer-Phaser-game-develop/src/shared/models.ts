export interface SpaceShip {
    name: string;
    id: string;
    x: number;
    y: number;
    ammo: number;
}
