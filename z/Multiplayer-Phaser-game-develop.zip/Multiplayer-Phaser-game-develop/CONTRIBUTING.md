Be awesome and your code shall get accepted :bowtie:
