// Tran Duy Duc, Lop K64K
#include <iostream>
#include <iomanip>
using namespace std;

void nhap(int &n, int *&ma, float *&dc) {
	int i = 0;
	cin >> n;
	ma = new int[n];
	dc = new float[n];
	for (; i < n; i++)
		cin >> ma[i] >> dc[i];
}

void danhSach(int n, int *ma, float *dc) {
	int i = 0;
	cout << ".\n" << setiosflags(ios::showpoint);
	for (; i < n; i++)
		cout << setw(5) << ma[i]
				<< setprecision(3)
				<< setw(8) << dc[i] << endl;
	cout << endl;
}

void datChuan(int n, float *dc) {
	int i = 0, count = 0;
	for (; i < n; i++)
		if (dc[i] >= 1.5) count++;
	cout << ".\n" << setw(5) << count
			<< setprecision(3) << setw(7)
			<< 100. * count / n << "%\n\n";
}

void honTrungBinh(int n, int *ma, float *dc) {
	float tb = 0;
	int i = 0, count = 0;
	for (; i < n; i++) tb += dc[i];
	tb /= n;
	cout << ".\n" << setiosflags(ios::showpoint);
	for (i = 0; i < n; i++)
		if (dc[i] > tb)
			cout << setw(5) << ma[i]
					<< setprecision(2)
					<< setw(8) << dc[i] << endl;
	cout << endl;
}

void sapXep(int n, int *&ma, float *&dc) {
	int i, j, k, t1;
	float t2;
	for (i = 0; i < n - 1; i++) {
		k = i;
		for (j = i + 1; j < n; j++)
			if (dc[j] > dc[k]) k = j;
		if (k != i) {
			t1 = ma[k];
			ma[k] = ma[i];
			ma[i] = t1;
			t2 = dc[k];
			dc[k] = dc[i];
			dc[i] = t2;
		}
	}
}

void danhSachGiamDan(int n, int *ma, float *dc) {
	sapXep(n, ma, dc);
	danhSach(n, ma, dc);
}

int main() {
	freopen("DS_VDV.TXT", "r", stdin);
	freopen("KETQUA.TXT", "w", stdout);
	int n, *ma;
	float *dc;
	nhap(n, ma, dc);
	danhSach(n, ma, dc);
	datChuan(n, dc);
	honTrungBinh(n, ma, dc);
	danhSachGiamDan(n, ma, dc);
	return 0;
}
