// Tran Duy Duc, Lop K64K
#include <iostream>
#include <cstring>
using namespace std;

void nhap(int &n, char **&ten) {
	int i = 0;
	char temp[255];
	cin >> n;
	cin.ignore();
	ten = new char*[n];
	for (; i < n; i++) {
		gets(temp);
		ten[i] = new char[strlen(temp) + 1];
		strcpy(ten[i], temp);
	}
}

void danhSach(int n, char **ten) {
	int i = 0;
	cout << ".\n";
	for (; i < n; i++)
		cout << ten[i] << endl;
	cout << endl;
}

void tenDaiNhat(int n, char **ten) {
	int i, max = strlen(ten[0]), found = 0;
	for (i = 1; i < n; i++)
		if (strlen(ten[i]) > max) max = strlen(ten[i]);
	cout << ".\n";
	for (i = 0; i < n; i++)
		if (strlen(ten[i]) == max) {
			if (found) cout << ", ";
			else found = 1;
			cout << i + 1;
		}
	cout << "\n\n";
}

int soTu(char *s1) {
	char *s = s1;
	int count = 1, i = 1;
	while (s[0] == 32) s++;
	if (s[0] == 0) count = 0;
	else for (; s[i]; i++)
		if ((s[i - 1] == 32) && (s[i] != 32)) count++;
	return count;
}

void ten2Tu(int n, char **ten) {
	int i = 0, found = 0;
	cout << ".\n";
	for (; i < n; i++)
		if (soTu(ten[i]) == 2) {
			if (found) cout << ", ";
			else found = 1;
			cout << i + 1;
		}
	if (!found) cout << 0;
	cout << "\n\n";
}

void sapXep(int n, char **&ten) {
	int i, j, k;
	char *temp;
	for (i = 0; i < n - 1; i++) {
		k = i;
		for (j = i + 1; j < n; j++)
			if (strcmp(ten[j], ten[k]) < 0) k = j;
		if (k != i) {
			temp = ten[k];
			ten[k] = ten[i];
			ten[i] = temp;
		}
	}
}

void danhSachTheoVan(int n, char **ten) {
	sapXep(n, ten);
	danhSach(n, ten);
}

int main() {
	freopen("DS_SV.INP", "r", stdin);
	freopen("DS_SV.OUT", "w", stdout);
	int n;
	char **ten;
	nhap(n, ten);
	danhSach(n, ten);
	tenDaiNhat(n, ten);
	ten2Tu(n, ten);
	danhSachTheoVan(n, ten);
	return 0;
}
